package com.example.food;

import static android.content.ContentValues.TAG;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class EditProduct extends AppCompatActivity {

protected void onCreate(Bundle savedInstanceState) {

    super.onCreate(savedInstanceState);
    setContentView(R.layout.edititem);
    Log.d(TAG,"onCreate:called");

    geteditproductinfo();
}

private void geteditproductinfo(){
    if(getIntent().hasExtra("Product Name")&&getIntent().hasExtra("Product ID")&&getIntent().hasExtra("Product DOE")&&getIntent().hasExtra("Product Amount")){
        String productname=getIntent().getStringExtra("Product Name");
        String productid=getIntent().getStringExtra("Product ID");
        String productdoe=getIntent().getStringExtra("Product DOE");
        String productamount=getIntent().getStringExtra("Product Amount");

        setedititem(productname,productid,productdoe,productamount);
    }
}
private void setedititem(String productname,String productid,String productdoe,String productamount){
    TextView pname,pamount,pdoe,prodidnumber;
    pname=findViewById(R.id.edititemname);
    pamount=findViewById(R.id.edititemnumber);
    pdoe=findViewById(R.id.edititemdoe);
    prodidnumber=findViewById(R.id.edititempid);

    pname.setText(productname);
    pamount.setText(productamount);
    pdoe.setText(productdoe);
    prodidnumber.setText(productid);

   /* updatebtn=findViewById(R.id.edititemupdate);
    cancelbtn=findViewById(R.id.edititemcancel);
    deletebtn=findViewById(R.id.edititemdelete);
    */
}

}
